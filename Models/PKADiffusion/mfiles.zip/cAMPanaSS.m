%Analytical solution to cAMP PDE SS and 3-compartment SS
%
% with
%FOR PDE
% 1) No flux boundary conditions
% 2) Submembrane PDE and AC compartment
% 3) No PDE in nucleus
% 4) Diffusive barrier at Nuclear membrane (no effect)
%
% [Rb,RL] da/dt=Da/r^2(d/dr(r^2da/dr))-kpde2*a +AC-kpde1*a
% (RN,Rb] da/dt=Da/r^2(d/dr(r^2da/dr))-kpde2*a
% [RN]    da/dt=DN/r^2(d/dr(r^2da/dr))
% [0,RN)  da/dt=Da/r^2(d/dr(r^2da/dr))
%
% We set r -> r*RL and t -> t*R_L^2/Da
%  and rescale a to r*u
%
% No flux at 0,RL da/dr=0 -> 1/r^2(-u + rdu/dr)=0
% Continuity at RN,Rb a-=a+ -> u-=u+
% Diff at RN,Rb da-/dr=da+/dr -> 1/r^2(-u- + rdu-/dr)=1/r^2(-u+ + rdu+/dr)
%                             -> du-/dr=du+/dr
%
% [Rb/RL,1]     du/dt=      d^2u/dr^2-(k1+k2)*a + alpha
% (RN/RL,Rb/RL] du/dt=      d^2u/dr^2-k2*a
% [RN/RL]       du/dt=DN/Da d^2u/dr^2
% [0,RN/RL)     du/dt=      d^2u/dr^2
%
% [Rb/RL,1]     u = Ab*cosh(sqrt(k1+k2)r)+Bb*sinh(sqrt(k1+k2)r)
%                   +alpha*r/(k1+k2)
% (RN/RL,Rb/RL] u = Ai*cosh(sqrt(k2)r)+Bi*sinh(sqrt(k2)r)
% [RN/RL]       u = Am*r + Bm
% [0,RN/RL)     u = An*r + Bn
%
%
% Bn = Bm = 0; Am = An
% Bb = Ab*cosh(sqrt(k1+k2)RL)-sqrt(k1+k2)*sinh(sqrt(k1+k2)RL))/
%      (sqrt(k1+k2)*cosh(sqrt(k1+k2)RL)-sinh(sqrt(k1+k2)RL))
% Ai = An*(sqrt(k2)*RN*cosh(sqrt(k2)RN)-sinh(sqrt(k2)RN))
% Bi = An*(-sqrt(k2)*RN*sinh(sqrt(k2)RN)+sinh(sqrt(k2)RN))
%
% Solve for An and Ab
%
%FOR 3-Compartment
% 
% a1 = phi2*a2;
% a2 = phi3*a3;
% a3 = AC/(kpde1+kpde2)+S2*Da/V3/rh2*(1-phi3)
%
% where 
%  phi2 = S1*Da/V1/rh1/(kpde2+S1*Da/V1/rh1); 
%  phi3 = S2*Da/V2/rh2/(kpde2+S1*Da/V2/rh1*(1-phi2)+S2*Da/V2/rh2)
%
% Usage:
%
% [aPDE,aODE]=cAMPanaSS(r,RL,Rb,RN,Da,DN,AC,kp,kpde2)
%
%
% r: scalar or vector with 0 < r <= RL
%   RL=radius of cell
%   Rb=radius to submembrane compartment
%   RN=radius to nucleus
%   Da=cAMP diffusion coefficient
%   DN=diffusion of cAMP through pore 
%   AC=adenyly cyclase cAMP produciton rate
%   kp=rate of PDE degradation of cAMP at submembrane
%   kpde2=rate of PDE degradation of cAMP in cytosol
%
% ex. 
% r=linspace(eps,7,1000);[aPDE,aODE]=cAMPanaSS(r,7,6.9,1,100,1,1000,10,10)

function [aPDE,aODE]=cAMPanaSS(r,RL,Rb,RN,Da,DN,AC,kp,kpde2)
%Rb, pause
kpde1=kp-kpde2;

V1=4/3*pi*(RN^3); 
V2=4/3*pi*(Rb^3-RN^3); 
V3=4/3*pi*(RL^3-Rb^3); %30.8 um^3 for RL=5um
V=V1+V2+V3;
S1=4*pi*RN^2;
S2=4*pi*Rb^2;%301um^2
rh1=Rb/2;
rh2=(RL-RN)/2;

%Redimensionalized pararmeters
alpha=RL^2*AC/Da; %uM
k1=RL^2*kpde1/Da; %nondim
k2=RL^2*kpde2/Da; %nondim

%psi = (cosh(sqrt(k1+k2))-sqrt(k1+k2)*sinh(sqrt(k1+k2)))/...
%      (sqrt(k1+k2)*cosh(sqrt(k1+k2))-sinh(sqrt(k1+k2)));
psi = (1-sqrt(k1+k2)*tanh(sqrt(k1+k2)))/...
      (sqrt(k1+k2)-tanh(sqrt(k1+k2)));

 
 phiA = RN/RL*cosh(sqrt(k2)*RN/RL)-sinh(sqrt(k2)*RN/RL)/sqrt(k2);
 phiB = -RN/RL*sinh(sqrt(k2)*RN/RL)+cosh(sqrt(k2)*RN/RL)/sqrt(k2);

 w1 = cosh(sqrt(k1+k2)*Rb/RL)+psi*sinh(sqrt(k1+k2)*Rb/RL);
 w2 = phiA*cosh(sqrt(k2)*Rb/RL)+phiB*sinh(sqrt(k2)*Rb/RL);
 w3 = sqrt(k1+k2)*(sinh(sqrt(k1+k2)*Rb/RL)+psi*cosh(sqrt(k1+k2)*Rb/RL));
 w4 = sqrt(k2)*(phiA*sinh(sqrt(k2)*Rb/RL)+phiB*cosh(sqrt(k2)*Rb/RL));

 w3w1 = sqrt(k1+k2)*(tanh(sqrt(k1+k2)*Rb/RL)+psi)/...
      (1+psi*tanh(sqrt(k1+k2)*Rb/RL));

 denom = w1*w4-w2*w3;
 An = alpha/(k1+k2)*(w1-w3*Rb/RL)/denom;
 Ab = alpha/(k1+k2)*(w2-w4*Rb/RL)/denom;
 
 Bb = psi*Ab;
 Ai = An*phiA;
 Bi = An*phiB;
 Am = An;
 Bm = 0;
 Bn = 0;
 
% N = 10000;
 
%  ib = round(Rb/RL*N);
%  in = round(RN/RL*N);
%  
%  r = linspace(0.000001,1,N);
%  rb = r(ib+1:N);
%  ri = r(in+1:ib);
%  rm = r(in);
%  rn = r(1:in);
 
% ub = (Ab*cosh(sqrt(k1+k2)*rb)+Bb*sinh(sqrt(k1+k2)*rb)+alpha*rb/(k1+k2));
% ui = (Ai*cosh(sqrt(k2)*ri)+Bi*sinh(sqrt(k2)*ri));
% um = (Am*rm + Bm);
% un = (An*rn + Bn);

ub = (r>Rb).*(Ab*cosh(sqrt(k1+k2)*r/RL)+Bb*sinh(sqrt(k1+k2)*r/RL)+alpha*r/RL/(k1+k2));
ui = (r<Rb).*(r>RN).*(Ai*cosh(sqrt(k2)*r/RL)+Bi*sinh(sqrt(k2)*r/RL));
um = (r==RN).*(Am*r/RL + Bm);
un = (r<RN).*(An*r/RL + Bn);

ab = RL*ub./r;
ai = RL*ui./r;
am = RL*um./r;
an = RL*un./r;

 phi2 = S1*Da/V1/rh1/(kpde2+S1*Da/V1/rh1); 
 phi2=1; %No kpde2 in nucleus
 phi3 = S2*Da/V2/rh2/(kpde2+S1*Da/V2/rh1*(1-phi2)+S2*Da/V2/rh2);

a3 = AC/(kpde1+kpde2+S2*Da/V3/rh2*(1-phi3));
a2 = phi3*a3;
a1 = phi2*a2;

aPDE = an+am+ai+ab;
aODE = [a1,a2,a3];

% a=[an,ai,ab];
%TotalComp = V3*a3+V2*a2+V1*a1;
%rs = [0,r(1:end-1)];
%VT=4/3*pi*RL^3*(r.^3-rs.^3);
%TotalPDE = sum(VT.*aPDE);
%
%AbsDiffAvgcAMPbtwCompandPDE = abs((TotalComp-TotalPDE)/V)

 