% cPKAssNoLbl2.m
% calculate the steady state cPKA without labels and
% with known steady state of cAMP from cAMPanaSS.m
%
%      kb(cAMP)
%      ->
%  P   <- 2C+R
%      ka
%
% ass = Const. 1/r sinh(sqrt(k) r)
%
%
% We wish to solve the integral equation for c
%
% V*CT = int S(r)*(c(r,t)+2p(r,t)) dr
% V(RL)CT=int_0^RL 4pi r^2(c+2p) dr
%        =int_0^RL 4pi r^2(c+2(RT-R)) dr
%        =int_0^RL 4pi r^2(c+2(RT-RT*K(r)/(c+K(r)))) dr
%        =int_0^RL 4pi r^2(c+2RT*c/(c+K(r))) dr
%
% f(c) = -V(RL)CT+4pi*int
%      =4*pi*(-RL^3/3 CT+int) 
%
% ex css=cPKAssNoLbl2(0.1,2,0.02,7,6.9,1,10,1,100,10,10,50,2,1000,1)
function [css,Rss,Ass,Pss] = cPKAssNoLbl2(RiT,RbT,CT,RL,Rb,RN,Da,DN,AC,kpde1,kpde2,ga,Ka,N,pp)

Vb=4/3*pi*(RL^3-Rb^3); %30.8 um^3
Sb=4*pi*Rb^2;%301um^2

ka = 1;
kb = @(a) ga*a.^2./(Ka^2+a.^2);
ass = @(r) cAMPanaSS(r,RL,Rb,RN,Da,DN,AC,kpde1,kpde2);


K = @(r) kb(ass(r))/ka;

RT = @(r) RbT*(r>Rb)+RiT*(r>RN).*(r<Rb);

 c = linspace(0,1,1000);
% for i = 1:1000
%  cplot(i)=cfun(c(i),K,RT,CT,RL);
% end
% plot(c,cplot,'b*-');
% hold on,
% pause
css = fzero(@(c) cfun(c,K,RT,CT,RL),0.1,optimset('display','off'));

r=linspace(eps,RL,N);
Rss = (RT(r)./(1+css.^2./K(r)))';
Pss = (RT(r)-Rss')';
Ass = ass(r)';

if pp==1
sf = 1;%max([Pss(RL),Rss(RL)])/ass(RL)

figure
plot(r,Pss,'b',r,sf*ass(r),'k',r,Rss,'r',r,css*ones(size(r)),'g','linewidth',2)
legend('PKA_{ss}','cAMP_{ss}','rPKA_{ss}','cPKA_{ss}','Location','Best')
set(gca,'fontsize',20)
xlabel('radius (\mum)','fontsize',20)
ylabel('Concentration (\muM)','fontsize',20)
%figure
%plot(r,K(r),'k',r,ass(r),'b')

end

function val=cfun(c,K,RT,CT,RL)
val=3/RL^3*quad(@(r) cint(r,c,K,RT),0,RL)-CT;

function val=cint(r,c,K,RT)
val = r.^2.*(c+2*RT(r).*c./(c+K(r)));
