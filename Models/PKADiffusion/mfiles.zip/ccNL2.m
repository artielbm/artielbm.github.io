% ccNL2.m - cPKA_cAMP_No_Label
% Brad Peercy 03/27/08
% 1-d Radial Diffusion of cPKA and cAMP - explicit scheme reaction
% imbedded in update rather than that in catDiff.m
%
% Update: from cPKAcAMPDiffLblSimple.m
%         Remove labeling to simplify
% Update: from ccNL.m by R+2C<->P
%
% Update: 07/14/2009 Change parameters
%                    to match fit to ccNL3.ode
%
% a = cAMP
% C = cPKA
% R = rPKA unbound to cPKA 
%   (Ri=R(rN:rb)=cytosolic, Rb=R(N)=boundary)
% P = PKA=R:2C
%   (Pi=P(rN:rb)=cytosolic, Pb=P(N)=boundary)
%
% r1 = thickness of Boundary
% r2 = thickness of Cytoplasm
% r3 = radius of Nucleus
% rL = r1+r2+r3 = 5um
%
% Vb = volume of boundary = 4/3*pi(RL^3-(r2+r3)^3)
% 
% ka/kb: forward/backward rate constants for 
% R + 2C <-> P=R:2C (kb depends on cAMP) 
% kb(a)=g*a^2/(a^2+Ka^2)
%
% Cytoplasm Equations:
% a_t = Da/r^2(r^2 a_r)_r + AC - kpde*a
% C_t = Dc/r^2(r^2 C_r)_r + 2kb(a)*(RT-R)-2ka*R*C^2
% R_t =   kb(a)*(RT-R)-ka*R*C^2
%
% Conservation of cPKA (not enforced, but checked in CTtest)
%
% V*CT=int(S(r)*C(r)+S(r)*P(r))
%
% Conservation of rPKA (enforced in equations)
%
% RT = P+R
%
% EqiMol Constraint (Total mol of C = Total mol of R)
% (enforced at initial condition) 
%
% V*CT=int(S(r)*R(r)+S(r)*2P(r))
%
% No Flux at (r=0, r=rL)
% a_r = 0
% C_r = 0
% Rf_r = 0
%
% Inputs:
%   epind = {0,1}
%   CnstStim = {0,1}
%   ExpStim = {'IBMX','Forskolin'}
% Outputs:
%
% Ex. [astor,Cstor,Rstor,Pstor,tstor,kpdestor,ACstor,fastor,r,Vol] = ccNL2(1,0,'IBMX');
%

function [astor,Cstor,Rstor,Pstor,tstor,kpdestor,ACstor,fastor,r,Vol] = ccNL2(epind,CnstStim,ExpStim)

%Parameters
Da = 100; %um^2/sec
Dc = 100; %um^2/sec
D1 = 0.0005; %um^2/s - Diffusion through nuclear membrane
%D1=Dc;
% Reversal rate dependence on cAMP

%%%% From ccNL3.ode %%%%%%
%par CT=0.5, RbT=0.52, RTT=0.24, AC=0.1, ka=1 Keq=0.0928, ga=1.5
%From fit to Matlab opt w/ AC=1
%par CT=0.5, RbT=0.52, RTT=0.24, AC=1, ka=1 Keq=0.13, ga=3.7

%%% Parameters - Old %%%%
%ga = 50;Ka = 2;AChi=40;AClo=10;ka = 1;kpdeoff = 1;kpdeon = 10;kpde2off = kpdeoff;kpde2on =  kpdeon;
%CT = 2;RTT=1;RbT = 1; %uM (V/V3*CT=23.67*CT) for all on boundary) total rPKA fixed on boundary 

%%% Parameters - New %%%%
%AClo=10;ga = 5.3;Ka = 1.6;kpdeoff = 1;
%AClo=1;ga = 3.7;Ka = 0.13;kpdeoff = 0.1;
AClo=1;ga = 1.6454;Ka = 0.0969;kpdeoff = 1;
CT = 0.5;RiT=0.2239;RbT = 0.5075; %uM (V/V3*CT=23.67*CT) for all on boundary) total rPKA fixed on boundary 
AChi=40;kpdeon =1000;kpde2off=0.01;kpde2on=0.01;ka = 1;

dr = 0.1; % um
dt = 0.0002; % seconds

% Stability constraint
% D*dt/dr^2<1/6 = 0.1667

T = 1211; % seconds
T=300;
el = dr; %um - fixed radius of reaction compartment

r1 = 1;
r2 = 5.9;
r3 = 0.1;
rL = r1+r2+r3; % um
V1=4/3*pi*r1^3;
V2=4/3*pi*((r2+r1)^3-r1^3);
V3=4/3*pi*((r3+r2+r1)^3-(r2+r1)^3);
V=V3+V2+V1;


Nnuc=r1/dr;

r = [(dr/2:dr:rL-el)';rL-el/2];
N = length(r);
alpha = dt/dr/dr;

rm = r-dr/2; % j-1/2
rm(N) = (N-1)*dr;
rp = r+dr/2; % j+1/2
rp(N) = (N-1)*dr+el;

Vol = 4/3*pi*(rp.^3-rm.^3);

Rden = 1./(rp.^2+rp.*rm+rm.^2);

Rp = 3*alpha*rp.^2.*Rden;
Rm = 3*alpha*rm.^2.*Rden;


kpde=kpde2on*ones(size(r));
kpde(1:Nnuc)=0;
kpde(N)=kpdeon;
AC=zeros(size(r));
AC(N) = AClo; %uM s^-1
%V*CT = V3*RbT+V2*RiT
%V*RTT = V3*RbT+V2*RiT
%RiT = (V*RTT-V3*RbT)/V2 %uM Mol Constraint
%RTT=(V2*RiT+V3*RbT)/V,pause
RT=RiT*ones(size(r));
RT(N)=RbT;
RT(1:Nnuc)=0;

% Call cAMP SS solver
%a=cAMPanaSS(r,rL,r1+r2,r1,Da,D1,AC(N),kpdeon,kpde2on);
% Call cPKA SS solver
%[css,R,a] = cPKAssNoLbl2(RiT,RbT,CT,rL,r1+r2,r1,Da,D1,AChi,kpdeon,kpde2on,ga,Ka,N,1);
%[css,R,a] = cPKAssNoLbl(RiT,RbT,CT,rL,r1+r2,r1,Da,D1,AClo,kpdeoff,kpde2off,ga,Ka,N,1);
%[css,R,a] = cPKAssNoLbl2(RiT,RbT,CT,rL,r1+r2,r1,Da,D1,AClo,kpdeoff,kpde2off,ga,Ka,N,1);
%[css,R,a] = cPKAssNoLbl2(RiT,RbT,CT,rL,r1+r2,r1,Da,D1,AClo,kpdeon,kpde2on,ga,Ka,N,1);

% Manual initial conditions
a = 0.0001*ones(size(r));
kb = ga*a.^2./(a.^2+Ka^2);
K=kb/ka;
css=0.02;
R = RT./(1+css.^2./K);

%disp('Check the PKA steady state')
%pause
%R=zeros(size(r));
%If RTT~=CT then adjust initial C 
C=css*ones(size(r));
%C(N)=sum(Vol)/V3*(CT-RTT)

% Initialization

if isnan(a(1))
    disp('No initial distribution')
    astor=[];Cstor=[];Rstor=[];Pstor=[];tstor=[];r=[];Vol=[];
    return
end

y=[a;C];

% Descritization Matrix

v1=[Da*Rm(2:N);Dc*Rm]/2;
v2=-[Da*(Rp+Rm);Dc*(Rp+Rm)]/2;
v3=[Da*Rp;Dc*Rp(1:N-1)]/2;

w1=[v1;0];w3=[0;v3];
B = speye(2*N) + spdiags([w1 v2 w3],-1:1,2*N,2*N); %explicit
% Boundary Conditions - No Flux
B(1,1) = 1-Da*Rp(1)/2;
B(1,2) = Da*Rp(1)/2;
B(N+1,N) = 0;
B(N+1,N+1) = 1-Dc*Rp(1)/2;
B(N+1,N+2) = Dc*Rp(1)/2;
% Boundary Conditions - cAMP Reaction
B(N,N-1) = Da*Rm(N)/2;
B(N,N) = 1-Da*Rm(N)/2;
B(N,N+1) = 0;
B(2*N,2*N-1) = Dc*Rm(N)/2;
B(2*N,2*N) = 1-Dc*Rm(N)/2;

M = speye(2*N) - spdiags([w1 v2 w3],-1:1,2*N,2*N);  %implicit
% Boundary Conditions - No Flux
M(1,1) = 1+Da*Rp(1)/2;
M(1,2) = -Da*Rp(1)/2;
M(N+1,N) = 0;
M(N+1,N+1) = 1+Dc*Rp(1)/2;
M(N+1,N+2) = -Dc*Rp(1)/2;
% Boundary Conditions - cAMP Reaction
M(N,N-1) = -Da*Rm(N)/2;
M(N,N) = 1+Da*Rm(N)/2;
M(N,N+1) = 0;
M(2*N,2*N-1) = -Dc*Rm(N)/2;
M(2*N,2*N) = 1+Dc*Rm(N)/2;

if epind~=1 %No C into Nucleus - Reflected
%Cytosol side
    B(N+Nnuc+1,N+Nnuc) = 0;
    B(N+Nnuc+1,N+Nnuc+1) = 1-Dc*Rp(Nnuc+1)/2;
    B(N+Nnuc+1,N+Nnuc+2) = Dc*Rp(Nnuc+1)/2;
    M(N+Nnuc+1,N+Nnuc) = 0;
    M(N+Nnuc+1,N+Nnuc+1) = 1+Dc*Rp(Nnuc+1)/2;
    M(N+Nnuc+1,N+Nnuc+2) = -Dc*Rp(Nnuc+1)/2;
%Nucleus side
    B(N+Nnuc,N+Nnuc+1) = 0;
    B(N+Nnuc,N+Nnuc) = 1-Dc*Rm(Nnuc)/2;
    B(N+Nnuc,N+Nnuc-1) = Dc*Rm(Nnuc)/2;
    M(N+Nnuc,N+Nnuc+1) = 0;
    M(N+Nnuc,N+Nnuc) = 1+Dc*Rm(Nnuc)/2;
    M(N+Nnuc,N+Nnuc-1) = -Dc*Rm(Nnuc)/2;
else %Nucleus provides only a diffusional barrier to C
%Cytosol side
    B(N+Nnuc+1,N+Nnuc) = D1*Rm(Nnuc+1)/2;
    B(N+Nnuc+1,N+Nnuc+1) = 1-(Dc*Rp(Nnuc+1)+D1*Rm(Nnuc+1))/2;
    B(N+Nnuc+1,N+Nnuc+2) = Dc*Rp(Nnuc+1)/2;
    M(N+Nnuc+1,N+Nnuc) = -D1*Rm(Nnuc+1)/2;
    M(N+Nnuc+1,N+Nnuc+1) = 1+(Dc*Rp(Nnuc+1)+D1*Rm(Nnuc+1))/2;
    M(N+Nnuc+1,N+Nnuc+2) = -Dc*Rp(Nnuc+1)/2;
%Nucleus side
    B(N+Nnuc,N+Nnuc+1) = D1*Rp(Nnuc)/2;
    B(N+Nnuc,N+Nnuc) = 1-(Dc*Rm(Nnuc)+D1*Rp(Nnuc))/2;
    B(N+Nnuc,N+Nnuc-1) = Dc*Rm(Nnuc)/2;
    M(N+Nnuc,N+Nnuc+1) = -D1*Rp(Nnuc)/2;
    M(N+Nnuc,N+Nnuc) = 1+(Dc*Rm(Nnuc)+D1*Rp(Nnuc))/2;
    M(N+Nnuc,N+Nnuc-1) = -Dc*Rm(Nnuc)/2;
end

t = 0;
i = 1;
inc = ceil(1/dt); % save every inc(rement) i.e. if dt = 0.01, inc = 2 -> 0.02s.
timesteps = round(T/dt);
Nt = ceil(timesteps/inc);

astor=zeros(Nt,N);
Cstor=zeros(Nt,N);
Rstor=zeros(Nt,N);
Pstor=zeros(Nt,N);
tstor=zeros(Nt,1);
kpdestor=zeros(Nt,N);
ACstor=zeros(Nt,1);
fastor=zeros(Nt,N);
fa=AC-kpde.*a;

tper = (1-CnstStim)*240 + CnstStim*2240;
tic
while t < T

    if mod(round(t/dt),inc)==0
        astor(i,:) = a;
        Cstor(i,:) = C;
        Rstor(i,:) = R;
        Pstor(i,:) = RT-R;
        tstor(i) = t;
        kpdestor(i,:) = kpde;
        ACstor(i) = AC(N);
        fastor(i,:) = fa;

        i=i+1;
    end
    %Stimulus Protocol
    if strcmp(ExpStim,'IBMX')
        if (mod(t,tper) > 180)
            kpde=kpde2off*ones(size(r));
            kpde(1:Nnuc)=0;
            kpde(N)=kpdeoff;
        else
            kpde=kpde2on*ones(size(r));
            kpde(1:Nnuc)=0;
            kpde(N)=kpdeon;
        end
    else %strcmp(ExpStim,'Forskolin')
        if (mod(t,tper) > 180)
            AC(N)=AChi;
        else
            AC(N)=AClo;
        end
    end
    
    kb = ga*a.^2./(a.^2+Ka^2);

    %Update Diffusible a,C,Cy w/boundary and cytosolic reactions
    fa = AC-kpde.*a;

    fc = 2*kb.*(RT-R)-2*ka*R.*C.^2;

    f = [fa;fc];
    y = M\(B*y+dt*f);


    %Update Nondiffusible rPKA,PKA
    R = R + dt*(kb.*(RT-R)-ka*R.*C.^2);

    a=y(1:N,1);
    C=y(N+1:2*N,1);

    t = t + dt;
    
end
toc
ccNLplot