% ccNLcompplot2 - plots four experiments
% 1),2) osc IBMX for EPI and TIRF 
% 3),4) constant IBMX for EPI and TRIF

% Osc Epi - save data here for use below
[astor,Cstor,Rstor,Pstor,tstor,kpdestor,ACstor,fastor,r,Vol]=ccNL2(1,0,'IBMX');
% Osc TIRF
ccNL2(0,0,'IBMX');
% Const Epi
ccNL2(1,1,'IBMX');
% Const TIRF
ccNL2(0,1,'IBMX');


% Show that the time to spatial equilibrium is rapid

figure
plot(tstor,astor(:,1),'r','linewidth',3), hold on
plot(tstor,astor(:,end),'b*')
set(gca,'fontsize',16)
xlabel('t (sec)','fontsize',16)
ylabel('cAMP (\muM)','fontsize',16)
legend('cAMP (nucleus)','cAMP (plasma-membrane)',0)

figure
plot(tstor,Cstor(:,1),'r','linewidth',3), hold on
plot(tstor,Cstor(:,11),'g','linewidth',3)
plot(tstor,Cstor(:,end),'b*')
set(gca,'fontsize',16)
xlabel('t (sec)','fontsize',16)
ylabel('cPKA (\muM)','fontsize',16)
legend('cPKA (nucleus)','cPKA (nuclear-membrane)','cPKA (plasma-membrane)',0)

figure
plot(r,astor(185,:),'k','linewidth',3), hold on
plot(r(end),astor(185,end),'b*','markersize',10),
plot(r(1),astor(185,1),'r*','markersize',10),
set(gca,'fontsize',16)
xlabel('r (\mum)','fontsize',16)
ylabel('cAMP (\muM)','fontsize',16)
axis([0 7 0 0.3])
set(gca,'xtick',[0 1 2 3 4 5 6 7])
set(gca,'xticklabel',[0 1 2 3 4 5 6 7])

figure
plot(r,Cstor(185,:),'k','linewidth',3), hold on
plot(r(end),Cstor(185,end),'b*','markersize',10),
plot(r(11),Cstor(185,11),'g*','markersize',10),
plot(r(1),Cstor(185,1),'r*','markersize',10),
set(gca,'fontsize',16)
xlabel('r (\mum)','fontsize',16)
ylabel('cPKA (\muM)','fontsize',16)
axis([0 7 0 0.5])
set(gca,'xtick',[0 1 2 3 4 5 6 7])
set(gca,'xticklabel',[0 1 2 3 4 5 6 7])
