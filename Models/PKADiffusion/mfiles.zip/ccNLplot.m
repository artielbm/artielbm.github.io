%ccNLplot.m - plot output from 
% [astor,Cstor,Rstor,Pstor,tstor,r,Vol] = ccNL(epind,CnstStim)

if ~exist('Da')
    infostr = 'No Data';
else
    infostr=sprintf('Da=%3.2f, Dc=%3.2f, \n ka=%2.1e, kb=%2.1e, \n kpdeon=%3.2f, kpdeoff=%3.2f, \n kpde2on=%3.2f, kpde2off=%3.2f, \n AC=%3.2f, D1=%2.1e, \n RiT=%3.2f, RbT=%3.2f',Da,Dc,ka,kb(N),kpdeon,kpdeoff,kpde2on,kpde2off,AC(N),D1,RiT,RbT);
end
    Nh=round((Nnuc+N)/2);

ep=1/6; %fraction of cytosol in nucleus measure
ni=4;  % 4 um into cytosol
Ni=round(ni/rL*N);
Nuc = (sum(Cstor(:,1:Nnuc),2)+...
       ep*(sum(Cstor(:,Nnuc+1:N-1),2)+...
            sum(2*Pstor(:,Nnuc+1:N-1),2))+...
       (Cstor(:,N)+...
            2*Pstor(:,N)))/(r1+ep*r2+r3);
Cyto = ((sum(Cstor(:,Ni:N-1),2)+...
             sum(2*Pstor(:,Ni:N-1),2))+...
        (Cstor(:,N)+...
             2*Pstor(:,N)))...
       /(rL-ni+r3);    
% Nuc = Cstor(:,1:Nnuc)*r(1:Nnuc)+...
%       ep*Cstor(:,Nnuc+1:N-1)*r(Nnuc+1:N-1)+...
%       ep*Pstor(:,Nnuc+1:N-1)*r(Nnuc+1:N-1)+...
%       Cstor(:,N)*r(N)+...
%       Pstor(:,N)*r(N);
%Nuc = (Cstor(:,+Pstor)*Vol/sum(Vol); %total projection
% Cyto = Cstor(:,Ni:N)*r(Ni:N)+...
%         Pstor(:,Ni:N)*r(Ni:N);    
% Nuc = Cstor(:,1:Nnuc)*Vol(1:Nnuc)/sum(Vol(1:Nnuc));
% Cyto = (Cstor(:,Nnuc+1:N)*Vol(Nnuc+1:N)+...
%        Pstor*Vol)/sum(Vol(Nnuc+1:N));

bigplot=0;
if bigplot==1
    disp('Have not doubled Pstor')
    figure
    vpos=get(gcf,'position');
    posshift=[300 0 0 0];
    set(gcf,'position',vpos-posshift)
    subplot(3,2,1),
    plot(tstor,astor(:,Nnuc),'b',tstor,astor(:,Nh),'g',tstor,astor(:,end),'r')
    ylabel('cAMP \muM')
    subplot(3,2,2),
    plot(tstor,Cstor(:,Nnuc),'b',tstor,Cstor(:,Nh),'g',tstor,Cstor(:,end),'r')
    ylabel('cPKA \muM')
    legend('Nuc','Cyt','Bdy')
    subplot(3,2,3),
    plot(tstor,Rstor(:,Nnuc),'b',...
        tstor,Rstor(:,Nh),'g',...
        tstor,Rstor(:,end-1),'r--',...
        tstor,Rstor(:,end),'r')
    ylabel('rPKA(free) \muM')
    CTtest=(Cstor*Vol+Pstor*Vol)/sum(Vol);
    subplot(3,2,4),
    plot(tstor,CT,'b-',...
        tstor,CTtest,'b*',...
        tstor,(Cstor*Vol)/sum(Vol),'c',...
        tstor,(Pstor(:,Nnuc+1:N-1)*Vol(Nnuc+1:N-1))/sum(Vol),'m',...
        tstor,Pstor*Vol(N)/sum(Vol),'g')
    ylabel('Divisions of cPKA \muM')
    title('(c=<free>,m=<bound in cyto>,g=bound at boundary)')
    xlabel('time (sec)')
    subplot(3,2,5)
    axpos=axis;
    text(0.05*axpos(2),0.5*axpos(4),infostr)
    axis off

    if epind==1
        subplot(3,2,6)
        plot(tstor,Nuc./Cyto)
        ylabel('EPI ratio (Nuc/Cyto)')
        xlabel('time (sec)')
    else
        subplot(3,2,6)
        plot(tstor,2*RbT./(2*Pstor(:,N)+Cstor(:,N)))
        ylabel('CFP/YFP')
        xlabel('time (sec)')
    end
    pause(1)
end %bigplot

if CnstStim==1
    pstyle='r-';
else
    pstyle='b-';
end
if epind==1
%     figure(54)
%     confocal=Cstor(:,5)/(Cstor(:,40)+2*Pstor(:,40));
%     plot(tstor,confocal,pstyle,'linewidth',2),hold on
%     ylabel('Confocal ratio (Nuc/Cyto) at (0.5um and 4um)','fontsize',20)
%     xlabel('time (sec)','fontsize',20)
%     set(gca,'fontsize',20)

    figure(55)
    plot(tstor,Nuc./Cyto,pstyle,'linewidth',2),hold on
    ylabel('EPI ratio (Nuc/Cyto)','fontsize',20)
    xlabel('time (sec)','fontsize',20)
    set(gca,'fontsize',20)
else
    figure(56)
    plot(tstor,2*RbT./(2*Pstor(:,N)+Cstor(:,N)),pstyle,'linewidth',2),hold on
    ylabel('CFP/YFP','fontsize',20)
    xlabel('time (sec)','fontsize',20)
    set(gca,'fontsize',20)
end

mplot=0;
if mplot==1
    figure
    plot(r,Pstor(1,:),'b',r,Rstor(1,:),'r',r,Cstor(1,:),'g'),hold on
    plot(r,Pstor(100,:),'b',r,Rstor(100,:),'r',r,Cstor(100,:),'g')
    plot(r,Pstor(1000,:),'b',r,Rstor(1000,:),'r',r,Cstor(1000,:),'g')
    hold off
    % Tn=length(tstor);
    % for i = 1:inc:Tn
    % plot(r,Pstor(i,:),'r',r,Rstor(i,:),'b',r,Cstor(i,:),'m')
    % axis([0 r(end) 0 2])
    % pause
    % end
end
%
% surfplot=1;
% if surfplot==1
%
%  inc=10;
%  [T,R]=meshgrid(tstor(1:inc:end),r);
%  colrow=size(T);
%  figure
%  set(gcf,'position',vpos+posshift)
% subplot(2,2,1),
%  surf(T,R,astor(1:inc:end,:)')
%  zlabel('cAMP \muM')
% subplot(2,2,2),
%  surf(T,R,Cstor(1:inc:end,:)')
%  zlabel('cPKA \muM')
% subplot(2,2,3),
%  surf(T,R,Rstor(1:inc:end,:)')
%  zlabel('rPKA (free) \muM')
%  xlabel('time (sec)')
%  ylabel('radius (\mum)')
%  axpos=axis;
%  text(axpos(2),0.5*axpos(4),0.5*axpos(6),infostr)
%  subplot(2,2,4)
%  surf(T,R,[zeros(colrow(2),Nnuc),Pstor(1:inc:end,Nnuc+1:N)]')
%  zlabel('PKA_{holo}-YFP (free) \muM')
%  xlabel('time (sec)')
%  ylabel('radius (\mum)')
% end

%Effective diffusion for cPKA given fixed cAMP
% K=kb/ka./astor;
% Psi=4*PfT*K.*Cstor./(1+K.*Cstor.^2).^2;
% figure
% subplot(1,2,1),surf(T,R,(1./(1+Psi(1:inc:end,:)')))
% subplot(1,2,2),surf(T,R,(1./sqrt(3*K(1:inc:end,:)')),'b',T,R,Cstor(1:inc:end,:)','r')
