function [ c0, b0 ] = eba( lambda, epsilon, beta, cinf, drel, r);
% EBA returns steady state radial solution to the rapid buffer 
% approximation.  This is the nondimensional version.
% 
% R is vector of nondimensional spatial positions.
%
% [ C0, B0 ] = EBA( LAMBDA, EPSILON, BETA, CINF, DREL, R);
%

binf = 1/(1+cinf);
nondimspaceconst = sqrt(epsilon*beta/binf);
c0 = cinf + 1./r.*exp(-r./nondimspaceconst);
b0 = binf*ones(1,length(c0));
c0 = c0(:);
b0 = b0(:);

return


