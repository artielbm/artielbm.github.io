function [ c01, b01 ] = eba2( lambda, epsilon, beta, cinf, drel, r);
% EBA2 returns the second order steady state radial solution to the rapid
% buffer approximation.  This is the nondimensional version.
% 
% R is vector of nondimensional spatial positions.
%
% [ C01, B01 ] = EBA2( LAMBDA, EPSILON, BETA, CINF, DREL, R);
%

[ c0, b0 ] = eba( lambda, epsilon, beta, cinf, drel, r);

binf = 1/(1+cinf);
A = 1/(epsilon*beta);
x = sqrt(A*binf)*r;

% note sqrt(A*binf) appears to be just 1/nondimspaceconst 
% which is 1/sqrt(epsilon*beta/binf) = sqrt(binf/epsilon*beta) 

gamma = 0.5772;

% These lines evaluate "exp(x).*(expint(2*x)-expint(3*x))" Need to do it in
% several steps because Inf*0=NaN.  When second term is zero the term evaluates
% to zero, regardless if exp(x) was machine sized or not.
expintpart = expint(2*x)-expint(3*x);
term = exp(x).*expintpart;
term(find(expintpart==0))=0;

c1 = sqrt(A*binf)/2/drel/binf^2./x.*(2-(2+x).*exp(-x)) ...
   + A/2/drel./x.*( term + exp(-x).*(-log(3/2)+expint(x)+log(x)+gamma) );
c1 = c1(:);

b1 = sqrt(A*binf)/drel./x.*(exp(-x)-1);
b1 = b1(:);

c01 = c0+beta*c1;
b01 = b0+beta*b1;

c01 = c01(:);
b01 = b01(:);

return


