function [ ca0, bm0 ] = ebadim(dc, dm, kmp, kmm, bmt, cainf, sigma, rdim);
% EBADIM returns steady state radial solution to the rapid buffer 
% approximation.  This is the dimensional version.
% 
% RDIM (in um) is vector of dimensional spatial positions.
%
% [ CA0, BM0 ] = EBADIM(DC, DM, KMP, KMM, BMT, CAINF, SIGMA, RDIM);
%

km=kmm/kmp;
bminf = km*bmt/(km+cainf);
a = sigma/(2*pi*dc);
spaceconst = sqrt(dc/kmp/bminf);
ca0 = cainf + a./rdim.*exp(-rdim./spaceconst);
bm0 = bminf*ones(1,length(ca0));

return


