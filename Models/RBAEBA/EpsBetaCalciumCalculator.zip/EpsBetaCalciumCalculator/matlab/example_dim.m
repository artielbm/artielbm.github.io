% EXAMPLE_DIM
% 
% Plots dimensional rapid buffer approximation result using RBADIM 
% and parameters from RBAPARAMS. 
% 
% This can easily be modified to present calculations using  
% EBADIM, IBADIM, or LINDIM. 
% 

clear

% Get parameters
[ dc, db, kp, km, bt, cainf, sigma ] = rbaparams(0);

% Define distances of interest
rdim = logspace(-4,2,100000);
rdim = rdim(:); % column vector

str = 'Dimensional RBA'; 
disp(str);
[ cdim, bdim ]  = rbadim( dc, db, kp, km, bt, cainf, sigma, rdim );
h = subplot(1,2,1);
loglog(rdim,cdim);
axis([ rdim(1) rdim(end) cainf Inf ]);
axis square
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
set(h,'YTick',[0.1 1 10 100 1000 ]) 
ylabel('[Ca^{2+}] (\muM)');
xlabel('r (\mum)');
title(str);
h = subplot(1,2,2);
semilogx(rdim,bdim);
axis([ rdim(1) rdim(end) 0 bt ]);
axis square
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
ylabel('[B] (\muM)');
xlabel('r (\mum)');
title(str);

return

