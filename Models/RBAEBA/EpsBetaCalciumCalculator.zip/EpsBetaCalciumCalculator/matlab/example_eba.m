% EXAMPLE_EBA
% 
% Plots dimensionless EBA (first and second order) using parameters 
% from EBAPARAMS and compares with numerical solution of the dimensionless
% full equations and solution obtained by linearization (NARAGHI). 
% 

clear 

showplane

% Get parameters
[ dc, db, kp, km, bt, cainf, sigma ] = ebaparams(0);

% Define distances of interest
rdim = logspace(-4,2,1000);

% Get nondimensional parameters
[ lambda, epsilon, beta, cinf, drel, eps_b, eps_c ] = ...
    nondimparams( dc, db, kp, km, bt, cainf, sigma );

% Define vector of dimensionless distances of interest
r = rdim./lambda;     

str = 'EBA, EBA2, Full Eq, and LIN'; 
str2 = 'EBA (red), EBA2 (green), Full Eq (blue), and LIN (magenta)'; 
disp(str2);
[ ceba, beba ]  = eba( lambda, epsilon, beta, cinf, drel, r );
[ ceba2, beba2 ]  = eba2( lambda, epsilon, beta, cinf, drel, r );
[ cfull, bfull ]  = fulleq( lambda, epsilon, beta, cinf, drel, r );
[ clin, blin ]  = lin( lambda, epsilon, beta, cinf, drel, r );

h = subplot(2,2,1);
loglog(r,cfull,'b',r,ceba,'r',r,ceba2,'g--',r,clin,'m-.');
axis([ r(1) r(end) cinf Inf ]);
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
set(h,'YTick',[0.1 1 10 100 1000 ]) 
axis square
ylabel('c');
xlabel('\rho');
title(str);

h = subplot(2,2,2);
semilogx(r,bfull,'b',r,beba,'r',r,beba2,'g--',r,blin,'m-.');
axis([ r(1) r(end) 0 1 ]);
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
ylabel('b');
xlabel('\rho');
axis square
title(str);

h = subplot(2,2,3);
plot(log10(eps_c),log10(eps_b),'*');

h = subplot(2,2,4);
plot(log10(eps_c),log10(eps_b),'*');

return

