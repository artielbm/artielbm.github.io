% EXAMPLE_IBA
% 
% Plots dimensionless IBA (first and second order) using parameters 
% from IBAPARAMS and compares with numerical solution of the dimensionless
% full equations.
% 

clear 

showplane

% Get parameters
[ dc, db, kp, km, bt, cainf, sigma ] = ibaparams(0);

% Define distances of interest
rdim = logspace(-4,2,1000);

% Get nondimensional parameters
[ lambda, epsilon, beta, cinf, drel, eps_b, eps_c ] = ...
    nondimparams( dc, db, kp, km, bt, cainf, sigma );

% Define vector of dimensionless distances of interest
r = rdim./lambda;     

str = 'IBA, IBA2, Full Eq'; 
str2 = 'IBA (red), IBA2 (green), Full Eq (blue)'; 
disp(str2);
[ ciba, biba ]  = iba( lambda, epsilon, beta, cinf, drel, r );
[ ciba2, biba2 ]  = iba2( lambda, epsilon, beta, cinf, drel, r );
[ cfull, bfull ]  = fulleq( lambda, epsilon, beta, cinf, drel, r );
h = subplot(2,2,1);
loglog(r,cfull,'b',r,ciba,'r',r,ciba2,'g--');
axis([ r(1) r(end) cinf Inf ]);
axis square
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
set(h,'YTick',[0.1 1 10 100 1000 ]) 
ylabel('c');
xlabel('\rho');
title(str);
h = subplot(2,2,2);
semilogx(r,bfull,'b',r,biba,'r',r,biba2,'g--');
axis([ r(1) r(end) 0 1 ]);
axis square
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
ylabel('b');
xlabel('\rho');
title(str);

h = subplot(2,2,3);
plot(log10(eps_c),log10(eps_b),'*');

h = subplot(2,2,4);
plot(log10(eps_c),log10(eps_b),'*');   

return

