% EXAMPLE_RBA
% 
% Plots dimensionless RBA (first and second order) using parameters 
% from RBAPARAMS and compares with numerical solution of the dimensionless
% full equations. 
% 

clear 

showplane

% Get parameters
[ dc, db, kp, km, bt, cainf, sigma ] = rbaparams(0);

% Define distances of interest
rdim = logspace(-4,2,1000);

% Get nondimensional parameters
[ lambda, epsilon, beta, cinf, drel, eps_b, eps_c ] = ...
    nondimparams( dc, db, kp, km, bt, cainf, sigma );

% Define vector of dimensionless distances of interest
r = rdim./lambda;     

str = 'RBA, RBA2, and Full Eq'; 
str2 = 'RBA (red), RBA2 (green), and Full Eq (blue)'; 
disp(str2);
[ crba, brba ]  = rba( lambda, epsilon, beta, cinf, drel, r );
[ crba2, brba2 ]  = rba2( lambda, epsilon, beta, cinf, drel, r );
[ cfull, bfull ]  = fulleq( lambda, epsilon, beta, cinf, drel, r );
h = subplot(2,2,1);
loglog(r,cfull,'b',r,crba,'r',r,crba2,'g');
axis([ r(1) r(end) cinf Inf ]);
axis square
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
set(h,'YTick',[0.1 1 10 100 1000 ]) 
ylabel('c');
xlabel('\rho');
title(str);
h = subplot(2,2,2);
semilogx(r,bfull,'b',r,brba,'r',r,brba2,'g');
axis([ r(1) r(end) 0 1 ]);
axis square
set(h,'XTick',[0.0001 0.001 0.01 0.1 1 10 100]) 
ylabel('b');
xlabel('\rho');
title(str);
  
h = subplot(2,2,3);
plot(log10(eps_c),log10(eps_b),'*');

h = subplot(2,2,4);
plot(log10(eps_c),log10(eps_b),'*');   

return

