function [ c, b ] = fulleq(lambda0, epsilon0, beta0, cinf0, drel0, r0);
% FULLEQ returns steady state radial solution to the full equations
% for the buffered diffusion of Ca2+. This is a nondimensional version.
%
% R is vector of nondimensional spatial positions.
%
% [ C, B ] = FULLEQ( LAMBDA, EPSILON, BETA, CINF, DREL, R, DISPFIG);
%

tolerance = 1e-12;
laplacian = 1; % 0 or 1 --- two slightly different schemes
dispfig = 0;

global lambda; global epsilon; global beta; global cinf; global drel;
lambda = lambda0; epsilon = epsilon0; beta = beta0; cinf = cinf0; drel = drel0;
global r; r = r0; r = r(:); % col vector  
global R; R = length(r);
global binf; binf = 1/(1+cinf);
global B; B = cinf-drel/beta*binf;

deltar = diff([ 0 ; r ]); 
deltarpo = deltar([ 2:R R ]); % repeat last deltarpo for RHS ghost point 
rpo = r+deltarpo; rmo = r-deltar; 
rs = r.^2; rpoh = r+deltarpo/2; rmoh = r-deltar/2; 
rpohs = rpoh.^2; rmohs = rmoh.^2;

if laplacian == 0
   etap = drel*2*rpohs./(rs.*(deltarpo+deltar).*deltarpo);
   etam = drel*2*rmohs./(rs.*(deltarpo+deltar).*deltar);
else
   % this method doesn't use b0 - see tdb(1) - since rmo(1)=etam(1)=0
   etap = drel*2*rpo./(r.*(deltarpo+deltar).*deltarpo);
   etam = drel*2*rmo./(r.*(deltarpo+deltar).*deltar);
end

% load values for diagnonals of tridiagonal matrix A 
tda(1:R)=0; tdb(1:R)=0; tdc(1:R)=0; % set size and null value
% small r equation gives 0 = 2*drel*db/dr-b/epsilon
% so b0 = b2-(deltar(1)+deltar(2))*b1/2/epsilon/drel
tda(1) = 0; % not used
tdb(1) = -(etam(1)+etap(1))-etam(1).*(deltar(1)+deltar(2))/2/drel/epsilon;
tdc(1) = etap(1)+etam(1);
tda(2:R-1) = etam(2:R-1);
tdb(2:R-1) = -(etam(2:R-1)+etap(2:R-1));
tdc(2:R-1) = etap(2:R-1);
tda(R) = etam(R); % normal 
tdb(R) = -(etam(R)+etap(R)); % normal
tdc(R) = 0; % but since b(R+1)=binf we have tdcRbinf term 
global tdcRbinf; tdcRbinf = etap(R)*binf; 
tda=tda(:); tdb=tdb(:); tdc=tdc(:);

% reorder to conform with matlabs spdiags funtion
tdaorder = [ 2:R 1 ];  tda = tda(tdaorder);
tdcorder = [ R 1:R-1 ]; tdc = tdc(tdcorder); 
% load tridiagonal matrix A 
global A; A = spdiags([ tda tdb tdc ], -1:1, R, R);

% MAIN 
% pick initial guess for b
b=binf*ones(R,1);
% central loop
change = 1+tolerance; % anything greater than tolerance
iteration = 1;
while change > tolerance,
   bnew = bupdate(b); bnew(find(bnew<0))=0; bnew(find(bnew>1))=1;
   change = norm(bnew-b,inf);
   b = bnew;
   c = drel/beta.*b+1./r+B;
   if dispfig
      disp(['Change for interation ' num2str(iteration) ' was ' ...
         num2str(change) '.']);
      loglog(r,b,'b-',r,c,'r-'); hold on;
      keyboard
   end
   iteration = iteration + 1;
end

c = c(:);
b = b(:);

return

%--------------------------
% Subfunctions 
%--------------------------
function freturn = f(b)
global r; global epsilon; global beta; global drel; global B; 
global R; global tdcRbinf;
freturn = -(drel/beta*b.^2+b./r+B.*b+b-1)./epsilon;
freturn(R) = freturn(R) + tdcRbinf; % contribution from lap at RHS boundary
return

%--------------------------
function fprimereturn = fprime(b)
global r; global epsilon; global beta; global drel; global B;
fprimereturn = -(drel/beta*2*b+1./r+B+1)./epsilon;
return

%--------------------------
function Freturn = F(b) % F is a vector
global A; 
Freturn = A*b+f(b);
return

%--------------------------
function Jreturn = J(b)
global A; global R; 
Jreturn = A+spdiags(fprime(b),0,R,R);
return

%--------------------------
function bupdatereturn = bupdate(b)
bupdatereturn = J(b)\(J(b)*b-F(b));
return

