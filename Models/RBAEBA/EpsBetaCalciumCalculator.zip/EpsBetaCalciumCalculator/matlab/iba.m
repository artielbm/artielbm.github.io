function [ c0, b0 ] = iba(lambda, epsilon, beta, cinf, drel, r);
% IBA returns steady state radial solution to the immobile buffer
% approximation.  In nondimensional form, cinf is the only free parameter.
%
% R is vector of nondimensionalized spatial positions.
%
% [ C0, B0 ] = IBA(LAMBDA, EPSILON, BETA, CINF, DREL, R);
%

c0 = 1./r + cinf;
c0 = c0(:);

b0 = 1./(1+c0);
b0 = b0(:);

return


