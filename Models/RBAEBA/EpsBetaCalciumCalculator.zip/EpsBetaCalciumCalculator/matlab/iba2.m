function [ c01, b01 ] = iba2(lambda, epsilon, beta, cinf, drel, r);
% IBA returns the second order steady state radial solution to the immobile
% buffer approximation. 
%
% R is vector of nondimensionalized spatial positions.
%
% [ C01, B01 ] = IBA2(LAMBDA, EPSILON, BETA, CINF, DREL, R);
%

[ c0, b0 ] = iba(lambda, epsilon, beta, cinf, drel, r);

r = r(:);

epsilonc = epsilon*beta;
epsilonb = epsilon*drel;

binf = 1/(1+cinf);
c1 = 1./epsilonc.*(b0-binf);
b1 = 2./r.^4./(1+c0).^4-c1./(1+c0).^2;

c01 = c0+epsilonb.*c1;
b01 = b0+epsilonb.*b1;

c01 = c01(:);
b01 = b01(:);

return


c0 = c0(:);
b0 = b0(:);

return


