function [ ca0, bm0 ] = ibadim( dc, dm, kmp, kmm, bmt, cainf, sigma, rdim);
% IBADIM returns steady state radial solution to the heat equation.
% This is the dimensional version.
% 
% RDIM (in um) is vector of dimensional spatial positions.
%
% [ CA0, BM0 ] = IBADIM(DC, DM, KMP, KMM, BMT, CAINF, SIGMA, RDIM);
%

a = sigma/2/pi/dc;
ca0 = a./rdim + cainf;
km=kmm/kmp;
bm0 = (bmt*km)./(km+ca0);

return


