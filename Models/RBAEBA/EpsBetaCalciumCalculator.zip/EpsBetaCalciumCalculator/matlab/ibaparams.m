function [ dc, db, kp, km, bt, cainf, sigma ] = ibaparams(dummy)
% IBAPARAMS returns parameters to demonstrate the (nearly) immobile buffer
% approximation.
%
% [ DC, DM, KP, KP, BT, CAINF, SIGMA ] = IBAPARAMS(0)
%

dc = 250 ;    % um^2/s
db =  5 ;    % um^2/s
kp = 100 ;    % uM^-1 s^-1
km = 1000 ;   % s^-1
bt = 100;     % uM
cainf = 0.1 ; % uM
ica = 1;      % pA 
sigma = ica.*(5182.4211); % convert from pA to umoles/s
% Note: 5182.4211 is 1/(2*9.648)*100000; the 2 is for the valence of Ca2+.

disp([ ' ']); 
disp([ 'Dimensional Parameters: ']); 
disp([ 'dc = ' num2str(dc) ' um^2/s']);
disp([ 'db = ' num2str(db) ' um^2/s']);
disp([ 'kp = ' num2str(kp) ' uM^-1 s^-1']);
disp([ 'km = ' num2str(km) ' s^-1']);
disp([ 'bt = ' num2str(bt) ' uM']);
disp([ 'cainf = ' num2str(cainf) ' uM']);
disp([ 'ica = ' num2str(ica) ' pA']);
disp([ 'sigma = ' num2str(sigma) ' umoles/s']); 
disp([ ' ']); 

return


