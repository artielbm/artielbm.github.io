function [ c0, b0 ] = lin( lambda, epsilon, beta, cinf, drel, r);
% LIN returns the solution of the equations for the buffered diffusion 
% of Ca2+ obtained by linearization. 
% 
% This is the nondimensional version.
% 
% R is vector of nondimensional spatial positions.
%
% [ C0, B0 ] = LIN( LAMBDA, EPSILON, BETA, CINF, DREL, R);
%

binf = 1/(1+cinf);
kappa = 1/beta/(1+cinf)^2;
A = 1/sqrt(epsilon)*sqrt((1+cinf)/drel*(1+kappa*drel));

c0 = cinf + 1/(1+kappa*drel)./r.*(1+kappa*drel*exp(-r*A));
b0 = binf + beta*kappa/(1+kappa*drel)./r.*(exp(-r*A)-1);

c0 = c0(:);
b0 = b0(:);

return

