function [ ca0, bm0 ] = lindim(dc, dm, kmp, kmm, bmt, cainf, sigma, rdim);
% LIN returns the solution of the equations for the buffered diffusion
% of Ca2+ obtained by linearization.
%
% This is the dimensional version.  
%
% RDIM (in um) is vector of dimensional spatial positions.
%
% [ CA0, BM0 ] = LINDIM(DC, DM, KMP, KMM, BMT, CAINF, SIGMA, RDIM);
%
% References:
%
% Pape PC, Jong DS, Chandler WK. Calcium release and its voltage dependence
% in frog cut muscle fibers equilibrated with 20 mM EGTA. J Gen Physiol.
% 1995 Aug;106(2):259-336.
%
% Naraghi M, Neher E.  Linearized buffered Ca2+ diffusion in microdomains and
% its implications for calculation of [Ca2+] at the mouth of a calcium channel.
% J Neurosci. 1997 Sep 15;17(18):6961-73.
%

km=kmm/kmp;
bminf = km*bmt/(km+cainf);
kappa = km*bmt/(km+cainf)^2;
tau = 1/(kmm+kmp*cainf);
oonlambdasquared = 1/tau*(1/dm+kappa/dc); 
nlambda = sqrt(1/oonlambdasquared); % not the same as our lambda 

ca0 = cainf + sigma/2/pi/(dc+kappa*dm)./rdim.*(1+kappa*dm/dc*exp(-rdim/nlambda));
bm0 = bminf + sigma*kappa/2/pi/(dc+kappa*dm)./rdim.*(exp(-rdim/nlambda)-1);

ca0 = ca0(:);
bm0 = bm0(:);

return


