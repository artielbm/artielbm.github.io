function [ lambda, epsilon, beta, cinf, drel, eps_b, eps_c ] = nondimparams( dc, dm, kp, km, bt, cainf, sigma )
% NONDIMPARAMS returns nondimensionalized parameters resulting from 
% a parameter set.
% 
% [ LAMBDA, EPSILON, BETA, CINF, DREL ] = NONDIMPARAMS( DC, DM, KMP, KMM, BMT, CAINF, SIGMA ) 
%

k=km/kp;
lambda = sigma/(2*pi*dc*k);
epsilon = (2*pi)^2*dc^3*k/sigma^2/kp;  
beta = k/bt;
cinf = cainf/k;
drel = dm/dc;
eps_b = epsilon*drel;
eps_c = epsilon*beta;

disp([ 'Non-dimensional parameters:' ]);
disp([ 'epsilon = ' num2str(epsilon) ]);
disp([ 'beta = ' num2str(beta) ]);
disp([ 'D = ' num2str(drel) ]);
disp([ 'eps_b = ' num2str(eps_b) ]);
disp([ 'eps_c = ' num2str(eps_c) ]);
disp([ 'log_10(eps_c) = ' num2str(log10(eps_c)) ]);
disp([ 'log_10(eps_b) = ' num2str(log10(eps_b)) ]);
disp([ ' ']); 

return


