function [ c0, b0 ] = rba(lambda, epsilon, beta, cinf, drel, r);
% RBA returns steady state radial solution to the rapid buffer 
% approximation.  This is the nondimensional version.
% 
% R is vector of nondimensional spatial positions.
%
% [ C0, B0 ] = RBA(LAMBDA, EPSILON, BETA, CINF, DREL, R);
%

binf = 1/(1+cinf);
B = cinf-drel/beta*binf;
phi = 1./r+B+1;
root = sqrt(phi.^2+4*drel/beta);
parenth = -phi+root;
b0 = (beta/2/drel).*parenth;
b0 = b0(:);
c0 = (0.5).*parenth+1./r+B;
c0 = c0(:);
return


