function [ c01, b01 ] = rba2(lambda, epsilon, beta, cinf, drel, r);
% RBA2 returns the second order steady state radial solution to the
% rapid buffer approximation.  This is the nondimensional version.
% 
% R is vector of nondimensional spatial positions.
%
% [ C01, B01 ] = RBA2(LAMBDA, EPSILON, BETA, CINF, DREL, R);
%

[ c0, b0 ] = rba(lambda, epsilon, beta, cinf, drel, r);

binf = 1/(1+cinf);
B = cinf-drel/beta*binf;
phi = 1./r+B+1;

b1 = 2*beta^2*drel./r.^4./(4*drel+beta.*phi.^2).^2;
b1 = b1(:);

c01 = c0 + epsilon*drel/beta.*b1;

b01 = b0 + epsilon.*b1;

c01 = c01(:);
b01 = b01(:);
return


