function [ ca0, bm0 ] = rbadim(dc, dm, kmp, kmm, bmt, cainf, sigma, rdim);
% RBADIM returns steady state radial solution to the rapid buffer 
% approximation.  This is the dimensional version.
% 
% RDIM (in um) is vector of dimensional spatial positions.
%
% [ CA0, BM0 ] = RBADIM(DC, DM, KMP, KMM, BMT, CAINF, SIGMA, RDIM);
%

km=kmm/kmp;
pm = bmt*km*dm; 
c1 = -sigma/(2*pi);
c2 = cainf*dc-pm/(cainf+km); 
R = -c1./rdim+c2;
X = R+dc*km; 
Y = 4.0*dc*pm;
root = sqrt(X.^2+Y); 
ca0 = (-dc*km+R+root)./(2.0*dc); 
bm0 = km*bmt./(ca0+km);

return


