The ode files can be run using the ODE solver xpp.  Parameters and initial conditions have
been set to correspond to the figure indicated by the filename.  Running with the defaults
(Initial Conditions, Go) should reproduce approximately the Ca2+ and cAMP traces in the figure.
Additional variables can be plotted using the xpp graphics commands.
